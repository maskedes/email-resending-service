import { Router, Request, Response } from 'express';
import { createApiKey, getAllApiKeys, getApiKeysByUserId, deactivateApiKey, deleteApiKey } from '../services/apiKeyService';
import { authMiddleware, requireAdmin, isAdminKey, trustedDashboardUserId } from '../middleware/auth';
import type { AuthRequest } from '../middleware/auth';

const router = Router();

router.post('/', authMiddleware, async (req: Request, res: Response): Promise<void> => {
  const { name, email } = req.body;
  const userId = trustedDashboardUserId(req);

  if (!name || !email) {
    res.status(400).json({
      error: {
        type: 'validation_error',
        message: 'Both "name" and "email" are required.',
      },
    });
    return;
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    res.status(400).json({
      error: {
        type: 'validation_error',
        message: 'Please provide a valid email address.',
      },
    });
    return;
  }

  const { apiKey, rawKey } = await createApiKey({ name, email, userId });

  res.status(201).json({
    id: apiKey.id,
    key: rawKey,
    name: apiKey.name,
    email: apiKey.email,
    created_at: apiKey.created_at,
    message: 'API key created successfully. Save this key securely - it will not be shown again.',
  });
});

router.get('/', authMiddleware, async (req: Request, res: Response): Promise<void> => {
  // Only honoured for trusted dashboard-proxy requests; a bare client-supplied
  // header cannot enumerate another user's keys.
  const userId = trustedDashboardUserId(req);
  // Only admin keys can list all keys; non-admin keys can only list their own
  if (!userId && !isAdminKey(req as AuthRequest)) {
    res.status(403).json({
      error: {
        type: 'forbidden',
        message: 'Admin rights required to list all API keys.',
      },
    });
    return;
  }
  const keys = userId ? await getApiKeysByUserId(userId) : await getAllApiKeys();

  res.json({
    data: keys.map((k) => ({
      id: k.id,
      name: k.name,
      email: k.email,
      is_active: k.is_active,
      total_emails_sent: k.total_emails_sent,
      created_at: k.created_at,
      last_used_at: k.last_used_at,
      allow_sms: k.allow_sms,
      allow_incoming_email: k.allow_incoming_email,
      forward_to: k.forward_to,
      is_admin: k.is_admin === true,
    })),
  });
});

router.delete('/:id', authMiddleware, requireAdmin, async (req: Request, res: Response): Promise<void> => {
  const success = await deactivateApiKey(req.params.id);

  if (!success) {
    res.status(404).json({
      error: {
        type: 'not_found',
        message: 'API key not found.',
      },
    });
    return;
  }

  res.json({
    message: 'API key deactivated successfully.',
  });
});

// Permanently delete an API key (auto-revokes + purges it and all child data:
// emails, events, webhooks, domains, templates). This is destructive and
// irreversible, so it requires an admin API key.
router.delete('/:id/delete', authMiddleware, requireAdmin, async (req: Request, res: Response): Promise<void> => {
  const success = await deleteApiKey(req.params.id);

  if (!success) {
    res.status(404).json({
      error: {
        type: 'not_found',
        message: 'API key not found.',
      },
    });
    return;
  }

  res.json({
    message: 'API key deleted successfully.',
  });
});

export default router;
